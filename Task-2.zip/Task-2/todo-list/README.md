# A simple to do list in a pure vanilla javascript

[DEMO PAGE HERE, I hope you like :)](http://expalmer.github.io/todo-list-vanilla-js/)